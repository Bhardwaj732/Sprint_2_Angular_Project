import { Component, OnInit } from '@angular/core';
import { CartQuantity } from 'src/app/pojo/cart-quantity';
import { Book } from 'src/app/pojo/classes/bookSahithi';
import { Cart } from 'src/app/pojo/classes/cartSahithi';
import { BookService } from 'src/app/services/book.service';
import { BookSahithiService } from 'src/app/services/bookSahithi.service';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {

  constructor(private bookService: BookService,
    private service: BookSahithiService) { }
  
  customerFullName:  string ='';
  books!: Book[];
  // cart:Cart=new Cart(1,"",2,1,1);
  newCart: Cart = new Cart();
  cartQuantity: CartQuantity = new CartQuantity();
  cartQuantity2!: CartQuantity;
  temp!: CartQuantity;
  cartValue2: number=0;
  message:any;
  bookId:any;
  title="";
  author='';
  cartValue: number=0;
  customerId: string = sessionStorage.getItem('userId') as string;


  ngOnInit(): void {
    console.log(this.customerId);
    this.service.getCartValue(this.customerId).subscribe(
      result => {
        this.cartValue=result.cartValue;
        console.log(result.cartValue);
      },
      error => {
        alert(error);
      }
    );
    this.getAllBooks();
  }


  public getAllBooks(): void {
    this.bookService.getBookList().subscribe(
      result => {
        this.books=result;
        this.customerFullName = sessionStorage.getItem('fullName') as string;
      },
      error => {
        alert(error);
      }
    );
  }


  public addToCart(data: Book){
    this.newCart.title = data.title;
    this.newCart.quantity = 1;
    this.newCart.price = data.price;
    this.newCart.customerId = sessionStorage.getItem('userId') as string;
    this.cartQuantity.customerId = sessionStorage.getItem('userId') as string;
    this.cartQuantity.cartValue = this.cartValue;
    this.service.addToCart(this.newCart).subscribe(
      ()=>{
        this.message="Item added";
        this.service.increaseCartValue(this.cartQuantity).subscribe(
          result => {
            this.cartQuantity2 = result;
            this.cartValue= this.cartQuantity2.cartValue;
            // this.ngOnInit();
          }
        )
      }
      );
        alert(data.title+" added to cart");
   }


   public search(){
    if(this.title!="")
    {
    this.books=this.books?.filter(res=>{
      return res.title?.toLocaleLowerCase().match(this.title?.toLowerCase())
    })
    }else if(this.title==""){
      this.ngOnInit();
    }
  }

}
